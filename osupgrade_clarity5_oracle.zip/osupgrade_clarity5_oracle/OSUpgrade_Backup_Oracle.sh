#!/usr/bin/env bash

dbName=$(echo $(hostname) | cut -d. -f1)
errorCode=0

if [ $# -eq 0 ]
then
  repoToUpgrade="qa"
else
  repoToUpgrade=${1}
fi
echo "Backup process starts at [$(hostname)]....."
startClarity(){
  /opt/gls/clarity/bin/run_clarity.sh start
}
handleError(){
  errorCode=1
}
signCerts(){
  cd /opt/gls/clarity/tools/propertytool
  java -jar omxprops-ConfigTool.jar set -y clarity.eSignature.enabled 'true'
  echo "Certs signed."
}
validateUpgrade(){
  enable_repo.sh -o -r $repoToUpgrade
  echo "y" | yum install ClarityLIMS-UpgradePreValidation*
  bash /opt/gls/ClarityUpgradeValidation/bin/validate.sh
  echo  "y" | yum remove ClarityLIMS-UpgradePreValidation
  echo "Upgrade to $repoToUpgrade has been pre-validated."
}
backupConfig(){
  unalias cp
  unalias mv
  echo "Creating backup folder in /opt/gls/clarity/users/glsjboss ."
  cd ~glsjboss

  rm -rf backups
  mkdir backups
  mkdir -p backups/conf
  cd /opt/gls/clarity/users/glsjboss/backups/conf
  pwd
  echo "yes"  | cp -Rf /opt/gls/clarity/users/glsftp .
  chown -R glsftp:claritylims glsftp
  echo "glsftp owner is changed to glsftp:claritylims"

  echo "yes"  | cp -Rf /etc/httpd/sslcertificate .
  echo "yes" | cp -Rf /opt/gls/clarity/glscontents .
  echo "yes"  | cp -Rf /opt/gls/clarity/customextensions .
  echo "yes"  | cp -Rf /etc/httpd/conf.d .
  echo "glsftp, sslcertificate , glscontent, customextensions, conf.d have been backed up!"

  thisip=$(ifconfig | grep "inet " | grep -v 127.0.0.1 |awk '{print $2}')
  echo "Backup Server ip:[$thisip].Backup Server Hostname:[$(hostname)]" > ipLog.txt

  rpm -qa | grep "BaseSpace\|Clarity" > clarityrpms.txt

  backupFileDir="/tmp/"
  backupFile="backups.zip"
  backupFilePath="${backupFileDir}${backupFile}"

  cd /opt/gls/clarity/users/glsjboss
  echo "yes"| rm -rf $backupFile

  zip -r backups.zip /opt/gls/clarity/users/glsjboss/backups
  chmod 777 $backupFile

  echo "yes"| rm -f $backupFilePath
  echo "yes"| cp -f $backupFile $backupFileDir
  cd $backupFileDir
}

signCerts
validateUpgrade
backupConfig || handleError

if [ $errorCode -eq 0 ]
then
  echo "Configuration have been backed up. Data from Oracle needs to be manaully transferred. Please check $backupFile here ($backupFileDir) and copy it to local machine."
else
  echo "Error to backup Clarity."
fi
