#!/usr/bin/env bash

dbName=$(echo $(hostname) | cut -d. -f1)
if [ $# -eq 0 ]
then
  backupZipUrl="/tmp/backups.zip"
else
  backupZipUrl=${1}
fi
errorCode=0
echo "Restore process starts at [$(hostname)] with [$backupZipUrl]....."

startClarity(){
  /opt/gls/clarity/bin/run_clarity.sh start
}
stopClarity(){
  /opt/gls/clarity/bin/run_clarity.sh stop
}
handleError(){
  errorCode=1
}
restoreConfig(){
  unalias cp
  unalias rm
  unalias unzip
  echo "Restoring [$backupZipUrl]....."
  backupUnzipFolder="unzipBackup"
  restoreFolder="/tmp/restore"
  cPwd=$restoreFolder/$backupUnzipFolder   #cPwd="/tmp/restore/unzipBackup"
  rm -rf $restoreFolder
  mkdir $restoreFolder
  mkdir $cPwd
  unzip $backupZipUrl -d $cPwd
  echo "Files have been unzipped into $cPwd."

  cd $cPwd
  cd opt/gls/clarity/users/glsjboss/backups/conf

  echo "Restoring the config from $backupUnzipFolder.."

  echo "yes"|cp -af .pgpass ~/
  echo "gldcontents has been restored."

  chown -R glsjboss:claritylims glscontents
  echo "yes"|cp -af glscontents/. /opt/gls/clarity/glscontents/
  echo "gldcontents has been restored."

  chown -R glsjboss:claritylims customextensions
  echo "yes"|cp -af customextensions/. /opt/gls/clarity/customextensions/
  echo "customextenstions has been restored."

  echo "glsftp to restore. Type no to overwrite......."
  cp -af glsftp/. /opt/gls/clarity/users/glsftp
  echo "glsftp has been restored."

  echo "yes"|cp -af conf.d/. /etc/httpd/conf.d/
  echo "/et/httpd/conf.d has been restored."

  echo "yes"|cp -af sslcertificate/. /etc/httpd/sslcertificate
  echo "ssl has been restored."

  thisip=$(ifconfig | grep "inet " | grep -v 127.0.0.1 |awk '{print $2}')
  echo "Restore Server ip:[$thisip].Restore Server Hostname:[$(hostname)]" >> ipLog.txt

  cd /opt/gls/clarity/users
  chown -R glsftp:claritylims glsftp

  echo "glsftp owner has been changed to claritylims."

  echo "Installing certificates...."

  [ -e certInput.txt ] && rm -f certInput.txt

  echo "/usr/gls/bin/certificates/keystore" >> certInput.txt
  echo "/etc/httpd/sslcertificate/star_cavc_illumina_com.key">> certInput.txt
  echo "/etc/httpd/sslcertificate/star_cavc_illumina.com.crt" >> certInput.txt
  echo "y" >> certInput.txt
  echo "/etc/httpd/sslcertificate/chain.crt" >> certInput.txt

  /opt/gls/clarity/config/installCertificates.sh < certInput.txt

  rm -f certInput.txt
  echo "Finished! Certs have been installed!"
}

migrateData(){
  echo "data Migrating starts."
  cd /opt/gls/clarity/config/
  su glsjboss "./migrate_claritylims_database.sh"
}
deleteElasticSearch(){
  service elasticsearch start
  curl -XDELETE 'http://localhost:9200/_all'
}
restartClarity(){
  run_clarity.sh stop
  run_clarity.sh start
}
pause(){
read -p "$*"
}

stopClarity
pause "Please transfer manually the data and schemas from backup-oracle to restore-oracle database. Afterwards, press enter here to continue restore config data.. "
restoreConfig
migrateData || handleError

echo "errorCode:$errorCode"
if [ $errorCode -eq 0 ]
then
  deleteElasticSearch
  restartClarity
  echo "Configuration and Data have been restored.Please check at [$(hostname)]."
else
  echo "Error to restore data."
fi
