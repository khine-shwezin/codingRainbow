[To Backup]
$. OSUpgrade_Backup_Oracle.sh 5.2
where 5.2 is the repo version to restore, that will be used here for upgrade validation. If not provided, the default is qa.

[To Restore]
$. OSUpgrade_Restore_Oracle.sh /home/yourname/backups.zip
where home/yourname/backups.zip is where backups.zip file is. If not provided, the default path the program will look for is /tmp/backups.zip.


Prerequisites and Note:

+ Backup Repo and Restore repo should have the required Clarity version installed, and data has been added, before backup and restore process.

+ After backup, you need to manually transfer backups.zip from backup repo to restore repo.

+ This script works on Oracle database.

+ Between Backup and Restore, ip switch needs to be done , by dev ops. Without ip switch, this script still works.



******  Versions and Dates ******

1.0 , 5 Dec 2019

*********************************


