cd /opt/gls/clarity/config/
echo "y" | yum remove ClarityLIMS-Reporting
enable_repo.sh -o -r reporting-qa-1.0.4
echo "y" | yum install ClarityLIMS-Reporting
cd /opt/gls/clarity/config/pending/

rm -f 70_input.txt

echo "2" >> 70_input.txt
echo "localhost" >> 70_input.txt
echo "5432" >> 70_input.txt
echo "clarityreporting" >> 70_input.txt
echo "clarityreportingetl" >> 70_input.txt
echo "apassword" >> 70_input.txt
echo "apassword" >> 70_input.txt
echo "reportreader" >> 70_input.txt
echo $(hostname) >> 70_input.txt

su glsjboss "./70_configure_claritylims_reporting_etl.sh" < 70_input.txt
rm -f 70_input.txt

etlFile="/opt/gls/clarity/tools/reporting/etl/conf/etl-config.properties"
sed -i 's|CLARITY_REPORTING_SCHEDULE=0 0 0 \* \* \*|CLARITY_REPORTING_SCHEDULE=0 \*/3 \* \* \* \*|g' $etlFile
sed -i 's|CLARITY_AUDITING_SCHEDULE=0 0 0 \* \* \*|CLARITY_AUDITING_SCHEDULE=0 \*/3 \* \* \* \*|g' $etlFile
sed -i 's|IN_PROGRESS_REPORTING_SCHEDULE=0 \*/5 \* \* \* \*|IN_PROGRESS_REPORTING_SCHEDULE=0 \*/3 \* \* \* \*|g' $etlFile
sed -i 's|CLARITY_ARTIFACT_UDFS_SCHEDULE=0 0 0 \* \* \*|CLARITY_ARTIFACT_UDFS_SCHEDULE=0 \*/3 \* \* \* \*|g' $etlFile
sed -i 's|CLARITY_DASHBOARD_SCHEDULE=0 \*/5 \* \* \* \*|CLARITY_DASHBOARD_SCHEDULE=0 \*/3 \* \* \* \*|g' $etlFile
sed -i 's|CLARITY_REAGENTS_SCHEDULE=0 0 0 \* \* \* \*|CLARITY_REAGENTS_SCHEDULE=0 \*/3 \* \* \* \*|g' $etlFile

sed -i 's|CLARITY_STEP_UDFS_SCHEDULE=0 0 0 \* \* \*|CLARITY_STEP_UDFS_SCHEDULE=0 \*/3 \* \* \* \*|g' $etlFile
sed -i 's|CLARITY_PROJECT_UDFS_SCHEDULE=0 0 0 \* \* \*|CLARITY_PROJECT_UDFS_SCHEDULE=0 \*/3 \* \* \* \*|g' $etlFile
sed -i 's|CLARITY_SAMPLE_UDFS_SCHEDULE=0 0 0 \* \* \*|CLARITY_SAMPLE_UDFS_SCHEDULE=0 \*/3 \* \* \* \*|g' $etlFile

sed -i 's|CLARITY_CLIENT_UDFS_SCHEDULE==0 0 0 \* \* \*|CLARITY_CLIENT_UDFS_SCHEDULE=0 \*/3 \* \* \* \*|g' $etlFile
sed -i 's|CLARITY_CONTAINER_UDFS_SCHEDULE=0 0 0 \* \* \*|CLARITY_CONTAINER_UDFS_SCHEDULE=0 \*/3 \* \* \* \*|g' $etlFile
sed -i 's|CLARITY_ACCOUNT_UDFS_SCHEDULE=0 0 0 \* \* \*|CLARITY_ACCOUNT_UDFS_SCHEDULE=0 \*/3 \* \* \* \*|g' $etlFile
echo "$etlFile has been updated."

/opt/gls/clarity/tools/reporting/etl/bin/reporting-etl-service.sh stop
/opt/gls/clarity/tools/reporting/etl/bin/reporting-etl-service.sh start
service postgresql-9.3 restart
run_clarity.sh stop
run_clarity.sh start

cd /opt/gls/clarity/tools/reporting
file=$(ls|grep .zip)
pathToCopy="/home/kszin/"
cp -f $file $pathToCopy
cd $pathToCopy

echo "Now copy $file under $pathToCopy to your local drive."
