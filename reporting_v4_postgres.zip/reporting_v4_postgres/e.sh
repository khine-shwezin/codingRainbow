etlFile="/opt/gls/clarity/tools/reporting/etl/conf/etl-config.properties"
cp $etlFile .
echo "Original File is $etlFile"
sed -i 's|CLARITY_REPORTING_SCHEDULE=0 0 0 \* \* \*|CLARITY_REPORTING_SCHEDULE=0 \*/3 \* \* \* \*|g' $etlFile
sed -i 's|CLARITY_AUDITING_SCHEDULE=0 0 0 \* \* \*|CLARITY_AUDITING_SCHEDULE=0 \*/3 \* \* \* \*|g' $etlFile
sed -i 's|IN_PROGRESS_REPORTING_SCHEDULE=0 \*/5 \* \* \* \*|IN_PROGRESS_REPORTING_SCHEDULE=0 \*/3 \* \* \* \*|g' $etlFile
sed -i 's|CLARITY_ARTIFACT_UDFS_SCHEDULE=0 0 0 \* \* \*|CLARITY_ARTIFACT_UDFS_SCHEDULE=0 \*/3 \* \* \* \*|g' $etlFile
sed -i 's|CLARITY_DASHBOARD_SCHEDULE=0 \*/5 \* \* \* \*|CLARITY_DASHBOARD_SCHEDULE=0 \*/3 \* \* \* \*|g' $etlFile
sed -i 's|CLARITY_REAGENTS_SCHEDULE=0 0 0 \* \* \* \*|CLARITY_REAGENTS_SCHEDULE=0 \*/3 \* \* \* \*|g' $etlFile

sed -i 's|CLARITY_STEP_UDFS_SCHEDULE=0 0 0 \* \* \*|CLARITY_STEP_UDFS_SCHEDULE=0 \*/3 \* \* \* \*|g' $etlFile
sed -i 's|CLARITY_PROJECT_UDFS_SCHEDULE=0 0 0 \* \* \*|CLARITY_PROJECT_UDFS_SCHEDULE=0 \*/3 \* \* \* \*|g' $etlFile
sed -i 's|CLARITY_SAMPLE_UDFS_SCHEDULE=0 0 0 \* \* \*|CLARITY_SAMPLE_UDFS_SCHEDULE=0 \*/3 \* \* \* \*|g' $etlFile

sed -i 's|CLARITY_CLIENT_UDFS_SCHEDULE==0 0 0 \* \* \*|CLARITY_CLIENT_UDFS_SCHEDULE=0 \*/3 \* \* \* \*|g' $etlFile
sed -i 's|CLARITY_CONTAINER_UDFS_SCHEDULE=0 0 0 \* \* \*|CLARITY_CONTAINER_UDFS_SCHEDULE=0 \*/3 \* \* \* \*|g' $etlFile
sed -i 's|CLARITY_ACCOUNT_UDFS_SCHEDULE=0 0 0 \* \* \*|CLARITY_ACCOUNT_UDFS_SCHEDULE=0 \*/3 \* \* \* \*|g' $etlFile
echo "Done update. Check at $etlFile."

