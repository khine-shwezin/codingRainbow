$setup_report.sh

This script does
1) install associated reporting package [reporting-qa-1.0.4] for Clarity 4.3.
2) Update configuration in /opt/gls/clarity/tools/reporting/etl/conf/etl-config.properties
3) Run reporting scripts
4) Restart postgresql, reporting-etl-service and clarity
5) Copy BasespaceLIMS-ReportingBundlexxx.zip into /home/kszin, to copy over to your local machine. 

After running this script, you need to copy BasespceLIMS-ReportingBundlexx.zip into your local machine, and setup in tableu server.
After extracting the zip file in Tableau server, enter below information while running deploy.bat file.

Tableau folder: D:\Program Files\Tableau\Tableau Server\9.2\bin
Tableau Server URL: https://tableau9.cavc.illumina.com
Tableau Site Name: haotan
User with publish rights to site: admin
Password for admin: CheckSpeckTypeKnew24
Database user name for ETL database: reportreader
Database password for ETL database: apassword


Before execute this script, you need to setup postgres db in your sever.This is something we can do in improvement. 

psql -U postgres
CREATE ROLE clarityreportingetl WITH NOSUPERUSER CREATEDB NOCREATEROLE LOGIN;
alter role clarityreportingetl with password 'apassword';
CREATE ROLE reportreader WITH NOSUPERUSER NOCREATEDB NOCREATEROLE LOGIN;
alter role reportreader with password 'apassword';

>>>> At root

createdb -U clarityreportingetl clarityreporting
Password:apassword

>>>>> at postgres

psql -U postgres
\c clarityreporting
ALTER ROLE reportreader LOGIN;


