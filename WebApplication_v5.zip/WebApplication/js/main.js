$(function(){
ShowFood();
var cArea = "";
currentTipPage = 1;
currentRecipePage = 1;

hearttoheart = {};
hearttoheart["image"] = "hearttoheartsummarized.png";
hearttoheart["name"] = "Heart to Heart";
hearttoheart["address"] = "20 Heart to Heart,Block B, #03-02Singapore 159053";
hearttoheart["phone"] = "65 123456";
hearttoheart["moreInfo"] = "This is long descriptions about what Heart to Heart wants to say";


willingheart = {};
willingheart["image"] = "willingheartsummarized.png";
willingheart["name"] = "Willing Heart";
willingheart["address"] = "123 Willing Heart Address, #03-02Singapore 159053";
willingheart["phone"] = "65 89898989";
willingheart["moreInfo"] = "<p>This is long descriptions about what Willingheart wants to say</p><p>Why West is important</p>";

feiyue = {};
feiyue["image"] = "feiyuesummarized.png";
feiyue["name"] = "feiyue";
feiyue["address"] = "20 feiyue,Block B, #03-02Singapore 159053";
feiyue["phone"] = "65 123456";
feiyue["moreInfo"] = "This is long descriptions about what feiyue wants to say from Central";


foodbank = {};
foodbank["image"] = "foodbanksummarized.png";
foodbank["name"] = "food bank";
foodbank["address"] = "123 foodbank Address, #03-02Singapore 159053";
foodbank["phone"] = "65 89898989";
foodbank["moreInfo"] = "<p>This is long descriptions about what foodbank wants to say</p><p>Why East is important</p>";

foodfromtheheart = {};
foodfromtheheart["image"] = "foodfromtheheartsummarized.png";
foodfromtheheart["name"] = "food from the heart";
foodfromtheheart["address"] = "20 foodfromtheheart,Block B, #03-02Singapore 159053";
foodfromtheheart["phone"] = "65 123456";
foodfromtheheart["moreInfo"] = "This is long descriptions about what foodfromtheheart wants to say from North";


lionshome = {};
lionshome["image"] = "lionshomesummarized.png";
lionshome["name"] = "foodbank";
lionshome["address"] = "123 lionshome Address, #03-02Singapore 159053";
lionshome["phone"] = "65 89898989";
lionshome["moreInfo"] = "<p>This is long descriptions about what lionshome wants to say</p><p>Why North is important</p>";


westShopList = {};
westShopList["hearttoheart"] = hearttoheart;
westShopList["willingheart"] = willingheart;

centralShopList = {};
centralShopList["feiyue"] = feiyue;

eastShopList = {};
eastShopList["foodbank"] = foodbank;

northShopList = {};
northShopList["foodfromtheheart"] = foodfromtheheart;
northShopList["lionshome"] = lionshome;


tipInfo = {};
var pg1TipDiv= "<div><div class='leftBigNote'>Keep track of what’s in your kitchen.</div>"+
"<div class='leftSmallNote'> Plan meals according to what you have, and what’s expiring soon.</div>"+
"<div class='rightBigNote'>Cook just enough. </div>"+
"<div class='rightSmallNote'> Determine the amount to "+
"be cooked with the diners’ "+
"appetites and eating habits."+
"</div>"+
"<div class='leftBigNote'>Use cut-off or the equivalent.</div>"+
"<div class='leftSmallNote'> Off-cuts of meat and "+
"vegetable stems or roots "+
"can be used to make stocks.</div>"+
"<div class='rightBigNote'> Cook a “use it up” "+
"meal every week</div>"+
"<div> </div>"+
"<div class='rightSmallNote'> Use only what’s already in your "+
"kitchen, including leftovers.</div>"+
"</div>";

var pg2TipDiv= "<div><div class='leftBigNote'>Check your kitchen before going grocery shopping.</div>"+
"<div class='leftSmallNote'>This prevents duplicate purchases. </div>"+
"<div class='rightBigNote'>Plan your purchases ahead.</div>"+
"<div class='rightSmallNote'>Make a shopping list and keep to it."+
"</div>"+
"<div class='leftBigNote'>Look past the imperfections.</div>"+
"<div class='leftSmallNote'>Bruised and blemished fruits "+
"and vegetables can be trimmed "+
"and used for cooking. </div>";

var pg3TipDiv= "<div><div class='leftBigNote'>Order only what you can eat. </div>"+
"<div class='leftSmallNote'>Start with less food on the table and order more later, if you need to. </div>"+
"<div class='rightBigNote'>Ask for advice.</div>"+
"<div class='rightSmallNote'>Consult the server on portion sizes to determine how much to order. "+
"</div>"+
"<div class='leftBigNote'>Downsize your order</div>"+
"<div class='leftSmallNote'>If you intend to eat less, ask for a smaller portion.</div>"+
"<div class='rightBigNote'>Don’t rush to order more.</div>"+
"<div class='rightSmallNote'>It takes 15-20 minutes after eating to start feeling full. </div>";

tipInfo["pg1"] = pg1TipDiv;
tipInfo["pg2"] = pg2TipDiv;
tipInfo["pg3"] = pg3TipDiv;

tipPageName = {};
tipPageName["pg1"] = "<div class='arrorTitleFont'>Tips for cooking at home</div>";
tipPageName["pg2"] = "<div class='arrorTitleFont'>Tips for grocery shopping</div>";
tipPageName["pg3"] = "<div class='arrorTitleFont'>Tips for eating out</div>";


recipeImage = {};
recipeImage["pg1"] = "images/watermelonRecipe.png";
recipeImage["pg2"] = "images/chickenRecipe.png";
recipeImage["pg3"] = "images/cheesyRecipe.png";
recipeImage["pg4"] = "images/pancakeRecipe.png";

recipePageName = {};
recipePageName["pg1"] = "<h1>Recipe for Water Melon</h1>";
recipePageName["pg2"] = "<h1>Recipe for Chicken</h1>";
recipePageName["pg3"] = "<h1>Recipe for Cheesy</h1>";
recipePageName["pg4"] = "<h1>Recipe for Pancake</h1>";

recipeDetailImage = {};
recipeDetailImage["pg1"] = "images/watermelonDetail.png";
recipeDetailImage["pg2"] = "images/chickenDetail.png";
recipeDetailImage["pg3"] = "images/chessyDetail.png";
recipeDetailImage["pg4"] = "images/pancakeDetail.png";

recipeDetailImage = {};
recipeDetailImage["pg1"] = "images/watermelonDetail.png";
recipeDetailImage["pg2"] = "images/chickenDetail.png";
recipeDetailImage["pg3"] = "images/chessyDetail.png";
recipeDetailImage["pg4"] = "images/pancakeDetail.png";


$("#map").on("click",ShowMap);
$("#food").on("click",ShowFood);
$("#why").on("click",ShowWhy);
$("#tips").on("click",ShowTips);
$("#recipes").on("click",ShowRecipes);

$("#west").on("click",ShowWestList);
$("#central").on("click",ShowCentralList);
$("#north").on("click",ShowNorthList);
$("#east").on("click",ShowEastList);

$("#BackBannerBtn").on("click", clickBackBanner);

$("#tipHomeCookId").on("click",{pg:1},fillTipPageFromMain);
$("#tipGroceryId").on("click",{pg:2},fillTipPageFromMain);
$("#tipEatingOutId").on("click",{pg:3},fillTipPageFromMain);

$("#leftArrow").on("click", clickLeft);
$("#rightArrow").on("click", clickRight);


$("#recipeLeftArrow").on("click", clickRecipeLeft);
$("#recipeRightArrow").on("click", clickRecipeRight);
$("#recipeHome").on("click", ShowRecipes);
cPage = 1;
});

function ShowRecipes(){
    $("#all>div").hide();
    $("#subtopic3").show();
	$("#recipeLeftArrow").hide();
	$("#recipeGuide").hide();
	$("#recipeGuide").hide();
	currentRecipePage = 1;
	$("#recipeMain").show();
	fillRecipePage();
}

function fillRecipePage(){
	$("#recipeLeftArrow").show();
	$("#recipeRightArrow").show();
	if(currentRecipePage == 1){
		$("#recipeLeftArrow").hide();
	}
	if(currentRecipePage > 1){
		$("#recipeLeftArrow").show();
	}
	if(currentRecipePage < 1){
		$("#recipeLeftArrow").hide();
	}
	if(currentRecipePage > 3){
		$("#recipeRightArrow").hide();
	}
	if(currentRecipePage < 3){
		$("#recipeRightArrow").show();
	}
	var page = "pg"+currentRecipePage;
	var imageName = recipeImage[page];
	var pageName =  recipePageName[page];
	var imgDetail = recipeDetailImage[page];
	$("#recipeImg").attr("src",imageName);
	$("#pgRecipeName").html(pageName);
	$("#recipeImg").on("click", {img:imgDetail},recipeClick);
}
function recipeClick(obj){
	var img = obj.data.img;
	$("#recipeDetailImg").attr("src", img);
	$("#recipeMain").hide();
	$("#recipeGuide").show();
}
function clickRecipeLeft(){
	currentRecipePage--;
	fillRecipePage();
}
function clickRecipeRight(){
	currentRecipePage++;
	fillRecipePage();
}


function ShowTips(){
    $("#all>div").hide();
    $("#subtopic2").show();
	$("#leftArrow").hide();
	fillTipPage();
	$("#tipMain").show();
	$("#tipBanner").hide();
	$("#tipDesc").hide();
}

function fillTipPage(){
	$("#leftArrow").show();
	$("#rightArrow").show();
	if(currentTipPage == 1){
		$("#leftArrow").hide();
	}
	if(currentTipPage > 1){
		$("#leftArrow").show();
	}
	if(currentTipPage < 1){
		$("#leftArrow").hide();
	}
	if(currentTipPage > 2){
		$("#rightArrow").hide();
	}
	if(currentTipPage < 2){
		$("#rightArrow").show();
	}
	var page = "pg"+currentTipPage;
	var pageData = tipInfo[page];
	var pageName =  tipPageName[page];
	$("#tipInfo").html(pageData);
	$("#pgTipName").html(pageName);
	$("#tipMain").hide();
}

function fillTipPageFromMain(obj){
	cPage =  obj.data.pg;
	currentTipPage = cPage;
	$("#leftArrow").show();
	$("#rightArrow").show();
	if(cPage == 1){
		$("#leftArrow").hide();
	}
	if(cPage > 1){
		$("#leftArrow").show();
	}
	if(cPage < 1){
		$("#leftArrow").hide();
	}
	if(cPage > 2){
		$("#rightArrow").hide();
	}
	if(cPage < 2){
		$("#rightArrow").show();
	}
	var page = "pg"+currentTipPage;
	var pageData = tipInfo[page];
	var pageName =  tipPageName[page];
	$("#tipInfo").html(pageData);
	$("#pgTipName").html(pageName);
	$("#tipMain").hide();
	$("#tipBanner").show();
	$("#tipDesc").show();
}

function clickLeft(){
	currentTipPage--;
	fillTipPage();
}

function clickRight(){
	currentTipPage++;
	fillTipPage();
}

function clickBackBanner(){
	$("#shops").show();
	$("#shopDetail").hide();
	$("#shopDesc").hide();
}
function onLoad(){
	console.log("onload");
}
function showShopDetails(obj){
	name= obj.data.name;
	imageName = $("#shop1").attr("src");
	console.log("imageName:"+imageName+", area:"+cArea);
}
function ShowMap(){
    $("#all>div").hide();
    $("#subtopic4").show();
}

function ShowFood(){
    $("#all>div").hide();
    $("#maintopic").show();
}

function ShowWhy(){
    $("#all>div").hide();
    $("#subtopic1").show();
}

function ShowWestList(){
    $("#all>div").hide();
    $("#westlist").show();
	$("#imageContainerClass").show();
	$("#imageAndDetail").show();
	$("#shops").show();
	$("#shopDetails").hide();
	$("#shopDesc").hide();
	cArea = "west";
	fillContainer("west");
}
function ShowCentralList(){
    $("#all>div").hide();
    $("#westlist").show();
	$("#imageContainerClass").show();
	$("#imageAndDetail").show();
	$("#shops").show();
	$("#shopDetails").hide();
	$("#shopDesc").hide();
	cArea = "central";
	fillContainer("central");
}
function ShowNorthList(){
    $("#all>div").hide();
    $("#westlist").show();
	$("#imageContainerClass").show();
	$("#imageAndDetail").show();
	$("#shops").show();
	$("#shopDetails").hide();
	$("#shopDesc").hide();
	cArea = "north";
	fillContainer("north");
}
function ShowEastList(){
    $("#all>div").hide();
    $("#westlist").show();
	$("#imageContainerClass").show();
	$("#imageAndDetail").show();
	$("#shops").show();
	$("#shopDetails").hide();
	$("#shopDesc").hide();
	cArea = "east";
	fillContainer("east");
}

function fillContainer(area){
	var imageDir = "images/"+iName;
	var iName = "";

	if(area == "west"){
		var i=1;
		var size = Object.keys(westShopList).length;
		if(size == 1 ){
			clearShop(2);
		}else{
			openShop(2);
		}
		for( var k in westShopList){
			var shopName = k;
			var shopInfoObj = westShopList[k];
			fillPage(i, shopInfoObj);
			i++;
		}
	}else if(area == "central"){
		var i=1;
		var size = Object.keys(centralShopList).length;
		if(size == 1 ){
			clearShop(2);
		}else{
			openShop(2);
		}
		
		for( var k in centralShopList){
			var shopName = k;
			var shopInfoObj = centralShopList[k];
			fillPage(i, shopInfoObj);
			i++;
		}
	}else if(area == "north"){
		var i=1;
		var size = Object.keys(northShopList).length;
		if(size == 1 ){
			clearShop(2);
		}else{
			openShop(2);
		}
		for( var k in northShopList){
			var shopName = k;
			var shopInfoObj = northShopList[k];
			fillPage(i, shopInfoObj);
			i++;
		}
	}else if(area == "east"){
		var i=1;
		var size = Object.keys(eastShopList).length;
		if(size == 1 ){
			clearShop(2);
		}else{
			openShop(2);
		}
		for( var k in eastShopList){
			var shopName = k;
			var shopInfoObj = eastShopList[k];
			fillPage(i, shopInfoObj);
			i++;
		}
	}else{
		var i=1;
		var size = Object.keys(myObj).length;
		if(size == 1 ){
			clearShop(2);
		}else{
			openShop(2);
		}
		
		for( var k in westShopList){
			var shopName = k;
			var shopInfoObj = westShopList[k];
			fillPage(i, shopInfoObj);
			i++;
		}
	}
}
function clearShop(i){
	var id = "#shop"+i;
	$(id).hide();
}
function openShop(i){
	var id = "#shop"+i;
	$(id).show();
}
function fillPage(i, infoObj){
	var id = "#shop"+i;
	var img = "images/"+infoObj["image"];
	var name = infoObj["name"];
	var addr = infoObj["address"];
	var phone = infoObj["phone"];
	var moreInfo = infoObj["moreInfo"];

	$(id).attr("src", img);
	$("#shop1Detail").attr("src", img);
	$("#shopName").text(name);
	$("#shopAddress").text(addr);
	$("#shopPhone").text(phone);
	$("#descInfo").html(moreInfo);
	$(id).on("click", {id:i,infoObj:infoObj}, clickFill);
	$("#shopDetail").hide();
}
function clickFill(obj){
	var id = obj.data.id;
	var infoObj = obj.data.infoObj;
	fillPage(id, infoObj);
	$("#shops").hide();
	$("#shopDetail").show();
	$("#shopDesc").show();
}
function gotomap(){
	console.log("On Map page");
}