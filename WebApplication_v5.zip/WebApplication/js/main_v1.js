$(function(){
ShowFood();
$("#map").on("click",ShowMap);
$("#food").on("click",ShowFood);
$("#why").on("click",ShowWhy);
$("#tips").on("click",ShowTips);
$("#recipes").on("click",ShowRecipes);
$("#west").on("click",ShowWestList);

$("#foodBankMain").on("click",{name: 'foodBankMain'}, showShopDetails);
$("#foodBank2Main").on("click", {name: 'foodBank2Main'},showShopDetails);
});

function onLoad(){
	console.log("onload");
	
}
function showShopDetails(obj){
	name= obj.data.name;
	console.log("Cliked shop detail, name:"+name);
	$("#westShops").hide();
	$("#shopDetails").show();
	if(name == "foodBankMain"){
		$("#foodBankMainBlock").show();
		$("#foodBank2MainBlock").hide();
	}
	if(name == "foodBank2Main"){
		$("#foodBank2MainBlock").show();
		$("#foodBankMainBlock").hide();
	}
}
function ShowMap(){
	console.log("showMap");
    $("#all>div").hide();
    $("#subtopic4").show();
}

function ShowFood(){
		console.log("ShowFood");
    $("#all>div").hide();
    $("#maintopic").show();
}

function ShowWhy(){
	console.log("Why");
    $("#all>div").hide();
    $("#subtopic1").show();
}

function ShowTips(){
    $("#all>div").hide();
    $("#subtopic2").show();
}

function ShowRecipes(){
    $("#all>div").hide();
    $("#subtopic3").show();
}

function ShowWestList(){
    $("#all>div").hide();
    $("#westlist").show();
	$("#imageContainerClass").show();
	$("#shopDetails").hide();
	console.log("Showing West List");
}
function gotomap(){
	console.log("On Map page");
	
}