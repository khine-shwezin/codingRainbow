echo "Start installing Active Directory LDAP"

if [ -z "$1" ]; then
        echo "No tenant entered - defaulting to localhost"
        tenant="localhost"
else
        tenant="$1"
fi


pushd /opt/gls/clarity/tools/propertytool/
java -jar omxprops-ConfigTool.jar set -y -f $tenant  authentication.type 'ldapAuthentication'
java -jar omxprops-ConfigTool.jar set -y -f $tenant  ldap.attribute.email 'mail'
java -jar omxprops-ConfigTool.jar set -y -f $tenant  ldap.attribute.fax 'facsimileTelephoneNumber'
java -jar omxprops-ConfigTool.jar set -y -f $tenant  ldap.attribute.firstName 'givenName'
java -jar omxprops-ConfigTool.jar set -y -f $tenant  ldap.attribute.lastName 'sn'
java -jar omxprops-ConfigTool.jar set -y -f $tenant  ldap.attribute.phone 'telephoneNumber'
java -jar omxprops-ConfigTool.jar set -y -f $tenant  ldap.attribute.title 'title'
java -jar omxprops-ConfigTool.jar set -y -f $tenant  ldap.attribute.userName 'sAMAccountName'
java -jar omxprops-ConfigTool.jar set -y -f $tenant  ldap.attribute.uuid 'uid'
java -jar omxprops-ConfigTool.jar set -y -f $tenant  ldap.automatedProvisioning.defaultDatastoreLab 'Administrative Lab'
java -jar omxprops-ConfigTool.jar set -y -f $tenant  ldap.automatedProvisioning.defaultRoles 'Labtech,Webclient'
java -jar omxprops-ConfigTool.jar set -y -f $tenant  ldap.automatedProvisioning.defaultRolesForLabLink 'Webclient'
java -jar omxprops-ConfigTool.jar set -y -f $tenant  ldap.automatedProvisioning.enabled 'true'
java -jar omxprops-ConfigTool.jar set -y -f $tenant  ldap.automatedProvisioning.interval '30000'
java -jar omxprops-ConfigTool.jar set -y -f $tenant  ldap.connectionTimeout '2000'
java -jar omxprops-ConfigTool.jar set -y -f $tenant  ldap.context 'authenticatedLdapContext'
java -jar omxprops-ConfigTool.jar set -y -f $tenant  ldap.datastoreGroupParentDn 'OU=Groups,OU=USRTP,OU=North America,DC=genologics,DC=com'
java -jar omxprops-ConfigTool.jar set -y -f $tenant  ldap.groupDn 'ClarityUsers'
java -jar omxprops-ConfigTool.jar set -y -f $tenant  ldap.groupMemberAttribute 'member'
java -jar omxprops-ConfigTool.jar set -y -f $tenant  ldap.managerDn 'CN=domainAdmin QA,CN=Users,DC=genologics,DC=com'
java -jar omxprops-ConfigTool.jar set -y -f $tenant  ldap.managerPass 'BreadListLadderAnswer25'
java -jar omxprops-ConfigTool.jar set -y -f $tenant  ldap.providerUrl 'ldap://windowsad.cavc.illumina.com:389/DC=genologics,DC=com'
java -jar omxprops-ConfigTool.jar set -y -f $tenant  ldap.searchFilter '(sAMAccountName={0})'
java -jar omxprops-ConfigTool.jar set -y -f $tenant  ldap.userDnPatterns ''
java -jar omxprops-ConfigTool.jar set -y -f $tenant  ldap.userSearchBase ''
java -jar omxprops-ConfigTool.jar set -y -f $tenant  ldap.useUUID 'false'
popd

echo "Configuration has been made to create the channel between AD LDAP and Clarity."

run_clarity.sh stop
run_clarity.sh start

echo "Checking AD LDAP users in postgres database..."

hostName=$(echo $(hostname)| cut -d. -f1)
echo "dbName:[$hostName]"

ldapUserName="activeldap"
ldapPorted=false
result=$(psql -U postgres -d $hostName -c "select firstname from researcher where firstname='$ldapUserName'")
echo "users result:[$result]"

if [[ $result == *"$ldapUserName"* ]]; then
  ldapPorted=true
  echo "Yes.[$ldapPorted]"
fi
echo "LDAP Users are ported into Clarity:[$ldapPorted]"
