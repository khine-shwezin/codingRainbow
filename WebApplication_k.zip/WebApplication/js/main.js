$(function(){
	burgerShown = true;
    $("#btn_subtopic1").on("click",ShowSubTopic1);
    $("#btn_subtopic2").on("click",ShowSubTopic2);
    $("#btn_subtopic3").on("click",ShowSubTopic3);
    $("#btn_subtopic4").on("click",ShowSubTopic4);
    $("#btn_subtopic5").on("click",ShowSubTopic5);
    $("#btn_home").on("click",ShowMainTopic);    
    ShowMainTopic();
    
});

function burgerClick(){
console.log("Burger Click");
	moveBurgers();
}
function HideSubTopics(){
    $("#all>div").hide();
}
function moveBurgers(){
	var a = [100, 200, 300, 400];
	for(var i=0; i<a.length; i++){
		var n = a[i];
		console.log("Move:"+n);
		var randomNum = Math.round(Math.random() * 300);
		TweenMax.to("#burger_id"+n, 6, {x:randomNum, y:300, scale:0.8, ease:Back.easeOut});
	}
}
function removeBurgers(){
	var a = [100, 200, 300, 400];
	for(var i=0; i<a.length; i++){
		var n = a[i];
		TweenMax.to("#burger_id"+n, 6, {x:1, y:1, scale:0, ease:Back.easeOut});
	}
}
function waste(){
	$("#main_header").html("<h1>This is Waste</h1><p>This is description of Waste</p>");
	$(".burger_class").show();
	if(burgerShown == true){
		moveBurgers();
		burgerShown = false;
	}else{
		removeBurgers();
		burgerShown = true;
	}
}
function why(){
	$("#main_header").html("<h1>This is Why</h1><p>This is description of Why</p>");
}
function tips(){
	$("#main_header").html("<h1>This is Tips</h1><p>This is description of Tips</p>");
}
function recipes(){
	$("#main_header").html("<h1>This is recipes</h1><p>This is description of Recipes</p>");
}

function ShowSubTopic1(){
    $("#subtopic1").show();
    TweenMax.from('#subtopic1',1,{left:'100px'})
}

function ShowSubTopic2(){
    $("#subtopic2").fadeIn();
    TweenMax.from('#subtopic2',1,{left:'100px'})
}

function ShowSubTopic3(){
    $("#subtopic3").fadeIn();
    TweenMax.from('#subtopic3',1,{left:'100px'})
}

function ShowSubTopic4(){
    $("#subtopic4").fadeIn();
    TweenMax.from('#subtopic4',1,{left:'100px'})
}

function ShowSubTopic5(){
    $("#subtopic5").fadeIn();
    TweenMax.from('#subtopic5',1,{left:'100px'})
}
function ShowMainTopic(){
    HideSubTopics();
    $("#maintopic").fadeIn();
    TweenMax.from('#maintopic',1,{right:'100px'})
}