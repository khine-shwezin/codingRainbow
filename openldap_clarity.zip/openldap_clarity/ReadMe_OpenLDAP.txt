ReadMe-OpenLDAP

$. SetupOpenLdap.sh

This script does
+ update the configuration to create the channel between Clarity and Open LDAP server
+ check if the ldap user [name="Justintime"] is imported into Clarity's Postgres database, in order to verify LDAP is successfully ported. 

Room to improve:
+ Add new user into LDAP via bash file, instead of fixed user name : Justin

