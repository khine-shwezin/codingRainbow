echo "Start installing OPEN LDAP"


yum install -y openldap-clients

ldapsearch -vv -x -h qaopenldap.cavc.illumina.com -p 389 -N -D cn=Manager,dc=my-domain,dc=com -w secret -b ou=genologics,dc=my-domain,dc=com -s sub "(cn=*)" cn mail sn

if [ -z "$1" ]; then
        echo "No tenant entered - defaulting to localhost"
        tenant="localhost"
else
        tenant="$1"
fi

pushd /opt/gls/clarity/tools/propertytool/
java -jar omxprops-ConfigTool.jar set -y -f $tenant  authentication.type 'ldapAuthentication'
java -jar omxprops-ConfigTool.jar set -y -f $tenant  ldap.attribute.email 'mail'
java -jar omxprops-ConfigTool.jar set -y -f $tenant  ldap.attribute.fax 'facsimileTelephoneNumber'
java -jar omxprops-ConfigTool.jar set -y -f $tenant  ldap.attribute.firstName 'cn'
java -jar omxprops-ConfigTool.jar set -y -f $tenant  ldap.attribute.lastName 'sn'
java -jar omxprops-ConfigTool.jar set -y -f $tenant  ldap.attribute.phone 'telephoneNumber'
java -jar omxprops-ConfigTool.jar set -y -f $tenant  ldap.attribute.title 'title'
java -jar omxprops-ConfigTool.jar set -y -f $tenant  ldap.attribute.userName 'uid'
java -jar omxprops-ConfigTool.jar set -y -f $tenant  ldap.attribute.uuid 'uid'
java -jar omxprops-ConfigTool.jar set -y -f $tenant  ldap.automatedProvisioning.defaultDatastoreLab 'Administrative Lab'
java -jar omxprops-ConfigTool.jar set -y -f $tenant  ldap.automatedProvisioning.defaultRoles 'Labtech,Webclient'
java -jar omxprops-ConfigTool.jar set -y -f $tenant  ldap.automatedProvisioning.defaultRolesForLabLink 'Webclient'
java -jar omxprops-ConfigTool.jar set -y -f $tenant  ldap.automatedProvisioning.enabled 'true'
java -jar omxprops-ConfigTool.jar set -y -f $tenant  ldap.automatedProvisioning.interval '30000'
java -jar omxprops-ConfigTool.jar set -y -f $tenant  ldap.connectionTimeout '2000'
java -jar omxprops-ConfigTool.jar set -y -f $tenant  ldap.context 'authenticatedLdapContext'
java -jar omxprops-ConfigTool.jar set -y -f $tenant  ldap.datastoreGroupParentDn 'ou=genologics,dc=my-domain,dc=com'
java -jar omxprops-ConfigTool.jar set -y -f $tenant  ldap.groupDn 'Administrative Lab'
java -jar omxprops-ConfigTool.jar set -y -f $tenant  ldap.groupMemberAttribute 'memberUid'
java -jar omxprops-ConfigTool.jar set -y -f $tenant  ldap.managerDn 'cn=Manager,dc=my-domain,dc=com'
java -jar omxprops-ConfigTool.jar set -y -f $tenant  ldap.managerPass 'secret'
java -jar omxprops-ConfigTool.jar set -y -f $tenant  ldap.providerUrl 'ldap://qaopenldap.cavc.illumina.com:389/dc=my-domain,dc=com'
java -jar omxprops-ConfigTool.jar set -y -f $tenant  ldap.searchFilter '(uid={0})'
java -jar omxprops-ConfigTool.jar set -y -f $tenant  ldap.userDnPatterns 'uid={0},ou=people'
java -jar omxprops-ConfigTool.jar set -y -f $tenant  ldap.userSearchBase ''
java -jar omxprops-ConfigTool.jar set -y -f $tenant  ldap.useUUID 'false'
popd
echo "Configuration has been made to create the channel between LDAP and Clarity."

run_clarity.sh stop
run_clarity.sh start

echo "Checking LDAP users in postgres database..."

hostName=$(echo $(hostname)| cut -d. -f1)
ldapUserName="Justin"
ldapPorted=false
result=$(psql -U postgres -d $hostName -c "select firstname from researcher where firstname='$ldapUserName'")
if [[ $result == *"$ldapUserName"* ]]; then
  ldapPorted=true
fi
echo "LDAP Users are ported into Clarity:[$ldapPorted]"
