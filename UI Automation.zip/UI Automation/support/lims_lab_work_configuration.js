Cypress.Commands.add('createWorkflow', (workflowName) => {
  cy.log('createWorkflow')
  cy.get('#navbar-menu-ul li a[href="/clarity/configuration"]').click()
    .wait(100)
    .get('.workflow-nav .isis-btn').click()
    .get('.wps-details-form .workflow-heading .editor-input').type(workflowName)
    .get('.wps-details-form .wps-button-bar-wrapper .isis-btn').contains('Save').click()
})

Cypress.Commands.add('activateWorkflow', (workflowName) => {
  cy.log('activateWorkflow')
  cy.get('#navbar-menu-ul li a[href="/clarity/configuration"]').click()
    .get('.workflow-nav .g-row-wrapper .workflow-col').contains(new RegExp('^' + workflowName + '$')).click()
    .get('#workflow-status label').contains('Activate').click()
    .get('.wps-details-form .wps-button-bar-wrapper .isis-btn').contains('Save').click()
    .get('.workflow-nav .g-row-wrapper .workflow-col').contains(new RegExp('^' + workflowName + '$'))
    .parents('.workflow-col').siblings('.workflow-status-col').should('have.text', 'Active')
})

Cypress.Commands.add('addProtocolToWorkflow', (protocolName, workflowName) => {
  cy.log('addProtocolToWorkflow')
  cy.get('#navbar-menu-ul li a[href="/clarity/configuration"]').click()
  cy.wait(200)
    .get('.workflow-nav .g-row-wrapper .workflow-col').contains(new RegExp('^' + workflowName + '$')).click()
    .get('.protocol-nav .bottom-protocol-table .g-row-wrapper .g-col-value').contains(new RegExp('^' + protocolName + '$')).parents('.g-row-wrapper')
    .then((protocolElm) => {
      let idx = Cypress.$('.protocol-nav .bottom-protocol-table .g-row-wrapper').index(protocolElm)
      cy.get('.protocol-nav .protocol-add-table .g-row-wrapper .add-remove-protocol-button').eq(idx).click()
      cy.get('.protocol-nav .protocol-table .g-row-wrapper .highlighted-row:last').should('have.text', protocolName)
    })
})

Cypress.Commands.add('createProtocol', (options) => {
  cy.log('createProtocol')
  let protocolName = options.protocolName
  cy.get('#navbar-menu-ul li a[href="/clarity/configuration"]').click()
    .wait(100)
    cy.log('protocol ' + cy.get('.protocol-nav .unified-protocol-table .protocol-col .g-col-value'))
    .get('.protocol-nav .unified-protocol-table .protocol-col .g-col-value')
    .then((protocols) => {
      let $protocolElm = null
      Cypress.$(protocols).each((idx, elm) => {
        if(Cypress.$(elm).text() == options.protocolName) {
          $protocolElm = Cypress.$(elm)
          return false
        }
      })

      if($protocolElm) {
        $protocolElm.click()
      }
      else {
        cy.get('.protocol-nav .isis-btn').click()
          .get('.wps-details-form .protocol-heading .editor-input').type(protocolName)
          .get('.wps-details-form .wps-button-bar-wrapper button').contains('Save').click()
          .get('.protocol-nav .unified-protocol-table .g-sel-row.r-selected').should('have.text', protocolName)
      }
      cy.createStep(options)
    })
})

Cypress.Commands.add('createStep', (options) => {
  cy.log('createStep')
  let steps = options.steps
  let i = 0

  if(steps.length > 0) {
    steps.forEach(($elm, idx) => {
      let stepName = $elm['stepName']
      let masterStepName = $elm['masterStepName']
      i = idx
      cy.log('idx ' + idx + ' elm stepName ' + stepName + ' masterStep ' + masterStepName)

      if(steps.length > 1 && idx > 0) {
        cy.get('.protocol-nav .unified-protocol-table .protocol-col .g-col-value')
        .then((protocols) => {
          let $protocolElm = null
          Cypress.$(protocols).each((idx, elm) => {
            if(Cypress.$(elm).text() == options.protocolName) {
              $protocolElm = Cypress.$(elm)
              return false
            }
          })

          if($protocolElm)
            $protocolElm.click()
        })
      }
      alert("hold for a sec");
      cy.get('.step-nav .step-column-header .isis-btn').click()
        .get('.protocol-step-details .protocol-step-heading .editor-input').should('is.visible').clear().type(stepName) // khine is.visible
        .get('.master-step-heading .entity-name-heading .rw-combobox button').click()
        .get('.master-step-heading .entity-name-heading .rw-combobox .rw-popup-container li')
        .contains(masterStepName)
        .then((masterStepElm) => {
          masterStepElm.click()
          cy.get('.protocol-step-details .wps-button-bar-wrapper button').contains('Save').click()
            .get('.step-nav .g-two-sided-row .g-left-row .r-selected').should('have.text', stepName)
        })
    })
  }
})

Cypress.Commands.add('addEditMasterStep', (options) => {
  cy.log('addEditMasterStep')
  let masterStepName = options['masterStepName']
  let milestoneWidgets = options['milestoneWidgets']
  cy.get('#navbar-menu-ul li a[href="/clarity/configuration"]').click()
  cy.wait(100)
  if(options.isEdit) {
    cy.get('.step-nav .master-step-col').contains(masterStepName).should('exist')
      .click()
  }
  else {
    cy.get('.step-nav .master-step-column-header .isis-btn').click()
      .get('.master-step-details .master-step-heading .editor-input').type(masterStepName)
  }

  cy.configureProtocolStep(options)
})

Cypress.Commands.add('configureProtocolStep', (options) => {
  cy.log('configureProtocolStep')
  let masterStepName = options.masterStepName
  let properties = options.properties

  if(properties) {
    if(properties.stepType && !options.isEdit)
      cy.get('.step-type-selection .type-badge').contains(properties.stepType).click()

    cy.get('.master-step-details .wps-button-bar-wrapper button').contains('Save').click()

    if(!options.isEdit)
      cy.get('.step-nav .g-two-sided-row .g-right-row .r-selected').should('is.visible').should('have.text', masterStepName)
  }

  if(options.milestoneWidgets) {
    options.milestoneWidgets.forEach(($elm, idx) => {
      if($elm.widgetName == 'Placement') {
        cy.get('.master-step-details .milestone-widget .milestone').contains('Placement').click()
        let containers = $elm.containers
        if(containers && containers.length > 0) {
          cy.get('.master-step-details .destination-containers-table .add-row-button').click()
          containers.forEach((container) => {
            cy.get('.master-step-details .drawered-container .drawer-content .g-sel-row .g-col').should('be.visible').contains(container).click()
          })
          cy.get('.master-step-details .drawered-container .drawer-header .isis-btn.check').click()
        }
      }
    })
    cy.get('.master-step-details .wps-button-bar-wrapper button').contains('Save').click()
  }
})
