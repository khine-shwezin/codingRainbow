Cypress.Commands.add('addEditCustomField', (options) => {
    cy.log('addEditCustomField')
    let fieldCategory = options.globalFieldName || options.masterStepFieldName
    let fieldName
    let fieldType = 'Text'
    let fieldDetails = options.fieldDetails
  
    if(fieldDetails) {
      fieldName = fieldDetails.fieldName
      fieldType = fieldDetails.fieldType
    }
  
    cy.get('#navbar-menu-ul li a[href="/clarity/configuration"]').click()
      .get('.tab-panel-header .tab-title').contains('CUSTOM FIELDS').click()
      if(options.masterStepFieldName)
        cy.get('.tab-panel-content .tab-panel-header .tab-title').contains('Master Step Fields').click()
  
      cy.get('.custom-field-pane-list .custom-field-list .custom-field-entity div').contains(fieldCategory.toUpperCase())
        .parents('.custom-field-list')
        .then((customFieldElm) => {
          let hdrCls = customFieldElm.find('.custom-field-header').attr('class')
          if(options.customFieldName) {
            // Select custom field element
            if(hdrCls.match(/r-collapsed/))
              customFieldElm.find('.expand-collapse').click()
  
            cy.get(customFieldElm).find('.custom-field-header').siblings('div').find('.custom-field-name')
              .contains(options.customFieldName).click()
          }
          else {
            // Click '+' button
            customFieldElm.find('.custom-field-entity').siblings('.isis-btn').click()
          }
  
          cy.get('.custom-field-pane-details .form').within(($fieldDetails) => {
            cy.log('field type ' + fieldType)
            cy.get('.name-association-preview-wrapper input').clear().type(fieldName)
              .get('.type-selector-widget .type-badge').contains(fieldType).click()
          })
          .get('.config-pane-details .header-button-bar .small-button-bar .isis-btn').contains('Save').click()
          .then(($elm) => {
            cy.get('.custom-field-pane-list .custom-field-list .custom-field-entity div').contains(fieldCategory.toUpperCase())
              .parents('.custom-field-header').siblings('div')
              .find('.custom-field-records .custom-field-list-item.selected .custom-field-name').should('have.text', fieldName)
          })
        })
  })
  