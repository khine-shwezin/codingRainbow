
Cypress.on('fail', (error, runnable) => {
  console.log("[lims_user_configurations.js] KHine error is here. Error:"+error.message);
  debugger

  // we now have access to the err instance
  // and the mocha runnable this failed on

  throw error // throw error to have test still fail
})

/*it('calls the "fail" callback when this test fails', function () {
  // when this cy.get() fails the callback
  // is invoked with the error
  cy.get('#firstName')
})*/

Cypress.Commands.add('createUser', (userName) => {
    cy.log('createUser')
    cy.get('#navbar-menu-ul li a[href="/clarity/configuration"]').click()
    cy.get('.tab-panel-header .tab-title').contains('USERS & CLIENTS').click()
    cy.contains('NEW USER').click()
    cy.get('#firstName').type("FirstyFist")
    cy.get('#lastName').type("LastyList")
    cy.get('#email').type("kszin@illumina.com")
    cy.get('#username').type("usernamex")
    cy.get('#phone').type("8888888")
    cy.get('.rw-multiselect-wrapper').click()
    cy.get('#role-mts__listbox__option__1').click()
    cy.get('.rw-multiselect-wrapper').click()
    cy.get('#role-mts__listbox__option__2').click()
    cy.get('#account-drp > .rw-input').click()
    cy.get('#account-drp__listbox__option__0').click()
    cy.contains('Save').click()
  })


import 'cypress-file-upload';

Cypress.Commands.add('uploadSamples', (fileName, fileType, selector,projectName) => {
  cy.get('#navbar-menu-ul li a[href="/clarity/samples"]').click().then(f => {
    cy.contains(projectName)
    .click();
  }).then(ff =>{
      cy.contains('UPLOAD SAMPLE LIST')
      .click();
      alert("Clicked Upload sample list"+JSON.stringify(ff));
  });

  const fileBytes = hexStringToByte(fileName);
  const testFile = new File([fileBytes], fileName, {
      type: "application/vnd.ms-excel"
  });

  cy.fixture(fileName)
  .then(fileContent => {
    var jsonC=JSON.parse(fileContent);
    cy.get(selector)
      .upload({ jsonC, fileName, mimeType: fileType, encoding: 'utf-8'}, { subjectType: 'input' })
    });

})

Cypress.Commands.add('uploadFile', (fileName, fileType, selector,projectName) => {
  cy.get('#navbar-menu-ul li a[href="/clarity/samples"]').click().then(f => {
    cy.contains(projectName)
    .click();
  }).then(ff =>{
      cy.get('#ext-gen1288')
      .click();
  }).then(fff => {
     cy.get('#upload-btn-btnInnerEl').click();
     cy.fixture(fileName)
     .then(fileContent => {
       alert("Start uploading");
       cy.get(selector)
         .upload({ fileContent, fileName, mimeType: fileType, encoding: 'utf-8'}, { subjectType: 'input' })
       }).then(v => {
         cy.get("#button-1073-btnInnerEl").should('be.visible').click();
       }
       );
  });
})

Cypress.Commands.add('uploadSampleFile', (fileName, fileType, selector,projectName) => {
  cy.get('#navbar-menu-ul li a[href="/clarity/samples"]')
  .click()
  .then(f => {
    cy.contains(projectName).click();
  })
  .then(ff =>{
      cy.contains('UPLOAD SAMPLE LIST').click();
  })
  .then(ffff => {
       cy.fixture(fileName)
       .then(fileContent => {
         cy.get(selector)
           .upload({ fileContent, fileName, mimeType: fileType, encoding: 'utf-8'},{ subjectType:'input'} )
           /*
            Error : expected expected 'You\'re trying to decode an invalid JSON String: \n\nThis error originated from your application code, not from Cypress.
            Have tried -  with proper json format, csv, xls, using JSON.stringify(), JSON.parse(),  none of them works.
           */
         }).then(v => {
           cy.get("#button-1073-btnInnerEl").click();
         }
      );
  });
})

Cypress.Commands.add('addWorkflow', (workflowName) => {
  cy.get('#navbar-menu-ul > li:nth-child(4) > a').should('is.visible').click();
  cy.get('.workflow-column-header > .btn-base').should('is.visible').click();
  cy.get('.editor-input').should('is.visible').click();
  cy.get('.editor-input').should('is.visible').type(workflowName);
  cy.get('.action .isis-btn-inner').should('is.visible').click();
  cy.contains(workflowName).should('is.visible').click();
  cy.get('.g-table:nth-child(2) .g-row-wrapper:nth-child(1) .btn-base:nth-child(1)').should('is.visible').click();
  cy.contains('Activate').should('is.visible').click();
  cy.get('.action .isis-btn-inner').should('is.visible').click();
})

Cypress.Commands.add('assignSamples', (prjName, workflowName) => {
  cy.get('#navbar-menu-ul > li:nth-child(3) > a').should('is.visible').click(); // click LabView
  cy.get('.work-block:nth-child(1) .sub-work:nth-child(1) .sub-work-text').should('is.visible').click()
  cy.wait(2000);
  cy.get('#navbar-menu-ul > li:nth-child(2) > a').should('is.visible').click();
  cy.contains('PROJECTS & Samples').should('is.visible').click();
  cy.wait(2000);
  cy.contains(prjName).should('is.visible').click();
  cy.contains('Select Group')
   .should('is.visible')
   .click()
   .then(ff => {
      let v= cy.get('.group-sample-count');
      let v1= cy.get('.group-sample-count').invoke('text');
      cy.contains('Assign To Workflow')
        .should('is.visible')
        .click()
        .then(f => {
              cy.wait(3000);
              cy.get('#rw_1__listbox').type(workflowName);
        }).then(ff => {
          let afterValue="Queue (4 samples)";
          cy.get('#navbar-menu-ul > li:nth-child(3) > a').should('is.visible').click(); // click LabView
          cy.get('.work-block:nth-child(1) .sub-work:nth-child(1) .sub-work-text').should('is.visible').click()
          cy.get('#label-1023').should('is.visible').should('contain', afterValue); // label-1023
          let expectedSampleMsg='Queue (4 samples)';
          cy.contains(expectedSampleMsg).then(f=>{
            alert(expectedSampleMsg+' is founded. Assign to workflow now.');
          });
        });
   });
  /*

  Need to get the number of samples from the page , create the string - Queue (X samples) and verify at the end

 */
  //x-component embedded-title read-only x-box-item x-toolbar-item x-component-default

})
