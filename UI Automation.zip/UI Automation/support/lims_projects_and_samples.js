Cypress.Commands.add('addProjects', (projects) => {
    cy.log('Add projects')
    if(!projects) {
      projects = [
        {
          "name": "Validation Project A",
          "account": "Administrative Lab",
          "client": "System Administrator"
        },
        {
          "name": "Validation Project B",
          "account": "Administrative Lab",
          "client": "System Administrator"
        },
        {
          "name": "Validation Project C",
          "account": "Administrative Lab",
          "client": "System Administrator"
        }
        ]
    }

    cy
      .get('#navbar-menu-ul li a[href="/clarity/samples"]').click()
      .wait(200)

    projects.forEach(($elm, idx, project) => {
      cy.log("$elm " + $elm['name'] + " idx " + idx)
      cy
        .get('#projects-container .section-header .add-icon')
        .click()

        // set project name
        .get('#project-name-editor input').click().type($elm['name'])

        // set project account
        .get('#project-account-editor .x-trigger-cell').click()
        .get('.x-boundlist-floating .x-boundlist-item')
        .then(accounts => {
          cy.log('ProjectAccount ' + accounts.text())
          let isNewAccount = true
          Cypress.$(accounts).each((accountIdx, accountElm) => {
            if(Cypress.$(accountElm).text() == $elm['account'])
              isNewAccount = false
          })

          if(isNewAccount)
            cy.get('#project-account-editor input').type($elm['account'])
          else
            cy.get('.x-boundlist-floating .x-boundlist-item').contains($elm['account']).click()
          cy.wait(100)

          // set project client
          .get('#project-contact-editor').click()
          .get('#project-contact-editor .x-trigger-cell').click()

          if(isNewAccount)
            cy.get('#project-contact-editor input').type($elm['client'])
          else {
            let isNewClient = true
            cy.get('div:visible.x-boundlist-floating .x-boundlist-item')
              .then(clients => {
                Cypress.$(clients).each((clientIdx, clientElm) => {
                  if(Cypress.$(clientElm).text() == $elm['client'])
                    isNewClient = false
                })
              })
              if(isNewClient)
                cy.get('#project-contact-editor input').type($elm['client'])
              else
                cy.get('div:visible.x-boundlist-floating .x-boundlist-item').contains($elm['client']).click()
            }

          cy
            // click outside project client
            .get("#project-editor-body").click()

            // save project
            .get('#project-save-cancel-btn-ctn div.isis-btn').contains('Save')
            .click()

            .get("div.project-list-item:first .project-list-item-headline-title").should('have.text', $elm['name'])
          })
      })
})

Cypress.Commands.add('addSamples', (options = {}) => {
  cy.log('addSamples')
  let numberOfSamples = options['numberOfSamples'] || 1
  let numberOfSamplesPerPage = 4
  const projectName = options['projectName']
  cy.get('#navbar-menu-ul li a[href="/clarity/samples"]')
    .trigger('mouseover')
    .get('a.nav-link').click()
    .wait(500)
    .get('.field-label:contains("Project Name")').siblings('div').find('.rw-combobox button').click()
    .get('.field-label:contains("Project Name")').siblings('div').find('.rw-list-option')
    .then(projects => {
      let $projectElm = null
      Cypress.$(projects).each((idx, elm) => {
        if(Cypress.$(elm).text() == projectName) {
          $projectElm = Cypress.$(elm)
          return false
        }
      })

      if($projectElm) {
        $projectElm.click()
      }
      else {
        cy.get('.field-label:contains("Project Name")').siblings('div').find('input').type(projectName + '{enter}')
          .get('.field-label:contains("Account Name")').siblings('div').find('input').type(projectName + ' Account{enter}')
          .get('.field-label:contains("Client Name")').siblings('div').find('.rw-combobox button').click()
          .get('.field-label:contains("Client Name")').siblings('div').find('input').type(projectName + ' Client{enter}')
        }

      if(numberOfSamples > 1)
        cy.get('.field-label:contains("Project Name")').siblings('span').children('.copy-across-inner').click()

      for(var i = 0; i < numberOfSamples; i++) {
        let counter = i
        let elmIdx = counter
        let sampleIdx = counter + 1

        if(elmIdx / numberOfSamplesPerPage >= 1) {
          let sampleOffset = parseInt(elmIdx / numberOfSamplesPerPage, 10) * numberOfSamplesPerPage
          elmIdx = elmIdx - sampleOffset
        }

        cy.get('.field-label:contains("Submitted Sample Name")').siblings('div').find('input')
          .then(inputElm => {
            cy.get(inputElm[elmIdx]).type('Sample ' + sampleIdx)
            if(numberOfSamples > 1 && sampleIdx < numberOfSamples)
              cy.get("#sample-acc-add-btn").click()
          })
      }

      cy.get('#sample-acc-submit-btn').click()
      /* khine comment out
      cy.get('.project-list-item .project-list-item-headline-title:contains(' + options['projectName'] + ')')
        .parent('div').siblings(".project-list-item-details").find('.project-list-item-details-samples-count').should('is.visible').should('have.text', numberOfSamples.toString())
      */
    })
})
