describe('ISIS-16155 - REG-LIMS: 5.X Sanity Test', function() {
    beforeEach(() => {
      cy.login()
    })
/*
    it('Step 8 - Create a new User', function() {
      cy.createUser('QA Container 1')
    })
*/   //projName="QA Sanity Test Project 1";
    it('Step 17-1: Create Project )', function() {
      var projName="Prj_11";
      /*
      cy.addProjects([
        {
        "name": projName,
        "account": "Administrative Lab",
        "client": "System Administrator"
        }
      ])
      */
       /*
        const fileName = 'uploadResources/j.json';
        const fileType = 'application/json';
        const fileType = 'application/vnd.ms-excel';
        const fileName = 'uploadResources/goodxls.xls';
        const fileName = 'uploadResources/goodcsv.csv';
        const fileType = 'text/csv';
        */

        const fileName = 'uploadResources/good.xlsx';
        const fileType = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
        const fileInput = 'input[type=file]';
        const projectName = projName;
        const workflowName='Workflow_Test_22';
        //cy.uploadSampleFile(fileName, fileType, fileInput, projectName);
        cy.log('Adding Workflow...');
        //cy.addWorkflow(workflowName);
        cy.log('Assuming that Project and samples have been created already and successfully.');
        cy.log('Assign samples into Workflow');
        cy.assignSamples(projName, workflowName);
      })
    })
