describe('ISIS-16155 - REG-LIMS: 5.X Sanity Test', function() {
    beforeEach(() => {
      cy.login()
    })

    it('Step 8 - Create a new container', function() {
      cy.createContainer('QA Container 1')
    })

    it('Step 9 - Add a new Master Step and configure its container', function() {
      cy.addEditMasterStep({
        'masterStepName': 'QA Master Step 2',
        'milestoneWidgets': [
          { 'widgetName': 'Placement', 'containers': [ 'QA Container 1', 'Illumina Flow Cell' ] },
          { 'widgetName': 'Queue', 'columnHeaders': [ 'Hdr1', 'Hdr2' ] }
        ],
        'properties': {
          'stepType': 'Standard QC'
        }
      })
    })
    /*
    it('Step 10 - Create Custom Fields', function() {
      cy.addEditCustomField({
        'masterStepFieldName': 'Add Multiple Reagents',
        'fieldDetails': {
          'fieldName': 'QA Master Step Custom Field 1',
          'fieldType': 'Numeric'
        }
      })

      cy.addEditCustomField({
        'globalFieldName': 'PROJECT',
        'fieldDetails': {
          'fieldName': 'QA Global Custom Field 1',
          'fieldType': 'Numeric'
        }
      })
    })

    it.only('Step 11 - Edit Global Custom Field', function() {
      cy.addEditCustomField({
        'globalFieldName': 'PROJECT',
        'customFieldName': 'QA Global Custom Field 1',
        'fieldDetails': {
          'fieldName': 'QA Global Custom Field 1 - Edited',
          'fieldType': 'Numeric'
        }
      })
    })
    */
    it('Step 15 - Create Workflow', function() {
      let workflowName = 'Validation Workflow 1'
      let options = {
        'protocolName': 'QA Protocol 1',
        'steps': [
          { 'stepName': 'QA Add Multiple Reagents 1', 'masterStepName': 'Add Multiple Reagents' },
          { 'stepName': 'QA Bioanalyzer 1', 'masterStepName': 'Bioanalyzer QC (DNA) 5.0' },
          { 'stepName': 'QA Aggregate QC DNA 1', 'masterStepName': 'Aggregate QC (DNA) 5.0' },
          { 'stepName': 'QA Pool Samples 1', 'masterStepName': 'Pool Samples' }
        ]
      }
      cy.createWorkflow(workflowName)
      cy.createProtocol(options)
      cy.addProtocolToWorkflow(options['protocolName'], workflowName)
      cy.activateWorkflow(workflowName)
    })

    // Projects & Samples
    it('Step 17 - Create Project and upload a full 96 Well plate of Samples)', function() {
      cy.addProjects([
        {
        "name": "QA Sanity Test Project 1",
        "account": "Administrative Lab",
        "client": "System Administrator"
        }
      ])
      // TODO: upload sample list
    })

    it('Step 18 - Create another Project and Add 12 samples', function() {
      cy.addProjects([
        {
        "name": "QA Sanity Test Project 2",
        "account": "Administrative Lab",
        "client": "System Administrator"
        }
      ])
        .addSamples({ projectName: 'QA Sanity Test Project 2', numberOfSamples: 12 })
    })
  })
