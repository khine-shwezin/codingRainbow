$(function(){
    
});

function moveFood(){
    $("#burgerId").show();
	$("#burgerId").css("z-index", "1");
	$("#burgerId").css("position", "absolute");
	TweenLite.to("#burgerId", 2.5, { ease: Bounce.easeOut, y: 500 });
}
function winggleBin(){
	$("#binId").show();
	$("#burgerId").hide();
	$("#binId").css("z-index", "1");
	$("#binId").css("position", "absolute");
    TweenMax.from("#binId",1,{scale:1,rotation:50,ease:Bounce.easeOut});

}
function binClick(){
	winggleBin();
}
function clickBtn(v){
	if( v == 'waste'){
		TweenMax.from("#wasteBtnId",1,{scale:1,rotation:100,ease:Bounce.easeOut});
        moveFood();
		$("#desc").html("<h2>Waste Header</h2><p> This is desc for waste!</p>");
	}
	if( v == 'why'){
		TweenMax.from("#whyBtnId",1,{scale:1,rotation:100,ease:Bounce.easeOut});
        moveFood();
		$("#desc").html("<h2>Why Header</h2><p> This is desc for WHY!</p>");
	}
	if( v == 'tips'){
		TweenMax.from("#tipsBtnId",1,{scale:1,rotation:100,ease:Bounce.easeOut});
        moveFood();
		$("#desc").html("<h2>Tips Header</h2><p> This is desc for Tips!</p>");
	}
	if( v == 'recipes'){
		TweenMax.from("#recipesBtnId",1,{scale:1,rotation:100,ease:Bounce.easeOut});
        moveFood();
		$("#desc").html("<h2>Recipes Header</h2><p> This is desc for Recipes!</p>");
	}
}
function onload(){
	$("#burgerId").hide();
	$("#burgerId").css("z-index", "-1");
	$("#burgerId").css("position", "absolute");
	
}