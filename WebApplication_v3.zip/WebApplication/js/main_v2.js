$(function(){
ShowFood();
var cArea = "";
hearttoheart = {};
hearttoheart["image"] = "hearttoheartsummarized.png";
hearttoheart["name"] = "Heart to Heart";
hearttoheart["address"] = "20 Heart to Heart,Block B, #03-02Singapore 159053";
hearttoheart["phone"] = "65 123456";
hearttoheart["moreInfo"] = "This is long descriptions about what Heart to Heart wants to say";


willingheart = {};
willingheart["image"] = "willingheartsummarized.png";
willingheart["name"] = "Willing Heart";
willingheart["address"] = "123 Willing Heart Address, #03-02Singapore 159053";
willingheart["phone"] = "65 89898989";
willingheart["moreInfo"] = "<p>This is long descriptions about what Willingheart wants to say</p><p>Why West is important</p>";

westShopList = {};
westShopList["hearttoheart"] = hearttoheart;
westShopList["willingheart"] = willingheart;

$("#map").on("click",ShowMap);
$("#food").on("click",ShowFood);
$("#why").on("click",ShowWhy);
$("#tips").on("click",ShowTips);
$("#recipes").on("click",ShowRecipes);
$("#west").on("click",ShowWestList);
$("#BackBannerBtn").on("click", clickBackBanner);

});

function clickBackBanner(){
	$("#shops").show();
	$("#shopDetail").hide();
	$("#shopDesc").hide();
}
function onLoad(){
	console.log("onload");
}
function showShopDetails(obj){
	name= obj.data.name;
	imageName = $("#shop1").attr("src");
	console.log("imageName:"+imageName+", area:"+cArea);
}
function ShowMap(){
	console.log("showMap");
    $("#all>div").hide();
    $("#subtopic4").show();
}

function ShowFood(){
	console.log("ShowFood");
    $("#all>div").hide();
    $("#maintopic").show();
}

function ShowWhy(){
	console.log("Why");
    $("#all>div").hide();
    $("#subtopic1").show();
}

function ShowTips(){
    $("#all>div").hide();
    $("#subtopic2").show();
}

function ShowRecipes(){
    $("#all>div").hide();
    $("#subtopic3").show();
}

function ShowWestList(){
    $("#all>div").hide();
    $("#westlist").show();
	$("#imageContainerClass").show();
	$("#imageAndDetail").show();
	$("#shops").show();
	$("#shopDetails").hide();
	$("#shopDesc").hide();
	cArea = "west";
	console.log("Showing West List");
	fillContainer("west");
}
function fillContainer(area){
	var imageDir = "images/"+iName;
	var iName = "";
	console.log("fillContainer:"+area);
	if(area == "west"){
		var i=1;
		for( var k in westShopList){
			var shopName = k;
			var shopInfoObj = westShopList[k];
			fillPage(i, shopInfoObj);
			i++;
		}
	}
}
function fillPage(i, infoObj){
	var id = "#shop"+i;
	var img = "images/"+infoObj["image"];
	var name = infoObj["name"];
	var addr = infoObj["address"];
	var phone = infoObj["phone"];
	var moreInfo = infoObj["moreInfo"];
	console.log("FillPage. id:"+id+", img:"+img);
	
	$(id).attr("src", img);
	$("#shop1Detail").attr("src", img);
	$("#shopName").text(name);
	$("#shopAddress").text(addr);
	$("#shopPhone").text(phone);
	$("#descInfo").html(moreInfo);
	$(id).on("click", {id:i,infoObj:infoObj}, clickFill);
	$("#shopDetail").hide();
	
}
function clickFill(obj){
	var id = obj.data.id;
	var infoObj = obj.data.infoObj;
	console.log("clickFill: id:"+id);
	fillPage(id, infoObj);
	$("#shops").hide();
	$("#shopDetail").show();
	$("#shopDesc").show();
	
}
function gotomap(){
	console.log("On Map page");
	
}